<?php include('header.php');?>

<script type="text/javascript" src="js/jquery.form.js"></script>
<script>
$(document).ready(function()
{
    $('#FileUploader').on('submit', function(e)
    {
        e.preventDefault();
        $('#submit').attr('disabled', ''); // disable upload button
        //show uploading message
        $("#output").html('<div class="msg-ok">Updating.. Please wait..</div>');
		
        $(this).ajaxSubmit({
        target: '#output',
        success:  afterSuccess //call function after success
        });
    });
});
 
function afterSuccess()
{	
	 
    $('#submit').removeAttr('disabled'); //enable submit button
   
}
</script>

<div class="maintitle">Edit Facts</div>

<div id="output"></div>
    
<div class="box">
<div class="inbox">

<?php

$id = $mysqli->escape_string($_GET['id']);

if($GetPost = $mysqli->query("SELECT * FROM facts WHERE id='$id'")){

    $GetRow = mysqli_fetch_array($GetPost);
	
	$YouUrl = $GetRow['video'];
	
	$CatId = $GetRow['catagory_id'];

	$GetPost->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

if(!empty($YouUrl)){

$YouTube = preg_match('#(\.be/|/embed/|/v/|/watch\?v=)([A-Za-z0-9_-]{5,11})#', $YouUrl, $matches);
if(isset($matches[2]) && $matches[2] != ''){
   
     $YoutubeCode = "http://www.youtube.com/watch?v=".$matches[2];

}
}else{
	
 $YouUrl = $GetRow['video'];
 	
}
	
?>

<form action="submit_edit.php?id=<?php echo $id;?>" id="FileUploader" enctype="multipart/form-data" method="post" >
  
    <label class="artlbl">Catagory</label>
    <div class="formdiv">
    <select name="catagory-select" id="catagory-select">
<?php

if($GetCat = $mysqli->query("SELECT id, cname FROM categories WHERE id='$CatId'")){

    $CatRow = mysqli_fetch_array($GetCat);

?>     
     <option value="<?php echo $CatRow['id'];?>"><?php echo $CatRow['cname'];?></option>
<?php     

	$GetCat->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
     
     
?>
      <option disabled value="">Select a Category</option>
<?php
if($CatSelect = $mysqli->query("SELECT id, cname FROM categories WHERE id!='$CatId'")){

    while($CatsRow = mysqli_fetch_array($CatSelect)){
				
?>
      <option value="<?php echo $CatsRow['id'];?>"><?php echo $CatsRow['cname'];?></option>
      <?php

}

	$CatSelect->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
?>
    </select>
    </div>
    
    <label class="artlbl">Headline</label>
    <div class="formdiv">
    <input type="text" name="Headline" id="Headline" value="<?php echo $GetRow['headline'];?>" />
    </div>
    
    <label class="artlbl">YouTube URL (optional)</label>
    <div class="formdiv">
    <input type="text" name="yTube" id="yTube" value="<?php if(!empty($YouUrl)){ echo $YoutubeCode;}?>" />
    </div>
    
    <label class="artlbl">Your Fact</label>
    <div class="formdiv">
    <textarea name="fact" id="fact" rows="10" cols="50"><?php echo $GetRow['fact'];?></textarea> 
    </div>
    
    <div class="formdiv">
    <label class="artlbl">Source URL (optional)</label>
    <input type="text" name="source" id="source" value="<?php echo $GetRow['source'];?>" />
    </div>
    
    <div class="formdiv">
    <div class="sbutton">
      <input type="submit" class="submit" id="submit" value="Update Post"/>
    </div>
    </div>
  </form>

</div>
</div><!--box-->
<?php include('footer.php');?>

 