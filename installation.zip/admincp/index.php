<?php include('header.php');?>
<div class="maintitle">Dashboard</div>
<div class="box-top">
<div class="inbox">
<div class="leftTable">
<table width="455" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="300">Post Statistics</td>
    <td width="160"></td>
   </tr>
 </thead>
<tbody>
<tr>
    <td>Total Number of Facts</td>
<?php
if($PendingNumber = $mysqli->query("SELECT id FROM facts")){

    $TotalNumber= $PendingNumber->num_rows;
  
?> 
     <td><?php echo $TotalNumber;?></td>

<?php

    $PendingNumber->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>     
</tr>
<tr>
<td>Total Approved Facts</td>
<?php
if($ApprovedFacts= $mysqli->query("SELECT id FROM facts WHERE active=1")){

    $ApprovedNumber = $ApprovedFacts->num_rows;
?>     

<td><?php echo $ApprovedNumber;?></td>

<?php

    $ApprovedFacts->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>

</tr>
<tr>
    <td>Total Approval Pending Facts</td>
<?php
if($PendingFacts = $mysqli->query("SELECT id FROM facts WHERE active=0")){

    $PendingNumber= $PendingFacts->num_rows;
?>      
    <td><?php echo $PendingNumber;?></td>
<?php

    $PendingFacts->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>  
    
</tr>
</tbody>
</table> 
</div>
<!--#-->
<div class="rightTable">
<table width="455" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="300">Site Statistics</td>
    <td width="160"></td>
   </tr>
 </thead>
<tbody>
<tr>
    <td>Total Site Views</td>
<?php
if($SiteStats = $mysqli->query("SELECT id,site_hits FROM settings WHERE id='1'")){

    $StatsNumber = mysqli_fetch_array($SiteStats);
  
?>     
	 <td><?php echo $StatsNumber['site_hits'];?></td>
<?php

    $SiteStats->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>     
</tr>
<tr>
    <td>Total Number of Users</td>
<?php 
if($TotalUsers = $mysqli->query("SELECT uid FROM users")){

    $UserNumber = $TotalUsers->num_rows;
  
?>      
    <td><?php echo $UserNumber;?></td>
<?php

    $TotalUsers->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>
    
</tr>
<tr>
    <td>Latest Registered User</td>
<?php 
if($LatestUser= $mysqli->query("SELECT uid, username FROM users ORDER BY uid DESC LIMIT 1")){

    $LatestUserName = mysqli_fetch_array($LatestUser);
  
?>    
    <td><?php echo $LatestUserName['username'];?></td>
<?php

    $LatestUser->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?>   
</tr>
</tbody>
</table> 
</div>
</div>
</div>
<div class="clear"></div>
<!--#-->

<div class="maintitle">Last 10 Approved Facts</div>
<div class="box-top">
<div class="inbox">

<table width="925" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="678">Title</td>
    <td width="150">Added Date</td>
   </tr>
 </thead>
<tbody>
	<?php
	if($LatestAprrovedFacts = $mysqli->query("SELECT * FROM facts WHERE active=1 ORDER BY id DESC LIMIT 10")){
		
		$LatestApp = $LatestAprrovedFacts->num_rows;

		while($LatestFactsRow = mysqli_fetch_array($LatestAprrovedFacts))
		{
			
		$LatestName = $LatestFactsRow['headline'];
		
		$LatestStr = strlen ($LatestName);
		if ($LatestStr > 50) {
		$LatestLg = substr($LatestName,0,50);
		}else{
		$LatestLg = $LatestName;}
		
		$LatestLink = preg_replace("![^a-z0-9]+!i", "-", $LatestLg);
		$LatestLink = urlencode($LatestLink);
		$LatestLink = strtolower($LatestLink);
		
		?>
		<tr>
     <td><a href="../fact-<?php echo  $LatestFactsRow['id'];?>-<?php echo $LatestLink;?>.html" target="_blank"><?php echo stripslashes( $LatestFactsRow['headline']);?></a></td>

    <td><abbr class="timeago" title="<?php echo $LatestFactsRow['date'];?>"></abbr></td>
</tr>
<?php
		}

    $LatestAprrovedFacts->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?> 
 </tbody>
</table>
<?php if($LatestApp<1){?> 
<div class="msg">There are no aprroved posts at the moment.</div>
<?php }?> 
<!--#-->
</div>
</div>
<!--#-->

<div class="maintitle">Last 10 Approvel Pending Facts</div>
<div class="box-top">
<div class="inbox">


<table width="925" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="678">Title</td>
    <td width="150">Added Date</td>
  </tr>
 </thead>
<tbody>
	<?php
	if($LatestPendingFacts = $mysqli->query("SELECT * FROM facts WHERE active=0 ORDER BY id DESC LIMIT 10")){
		
		$LatestPen = $LatestPendingFacts->num_rows;

		while($PendingFactsRow = mysqli_fetch_array($LatestPendingFacts))
		{
		
		$LatestPendingName = $PendingFactsRow['headline'];
		
		$LatestPendingStr = strlen ($LatestPendingName);
		if ($LatestPendingStr > 50) {
		$LatestPendingLg = substr($LatestPendingName,0,50);
		}else{
		$LatestPendingLg = $LatestPendingName;}
		
		$LatestPendingLink = preg_replace("![^a-z0-9]+!i", "-", $LatestPendingLg);
		$LatestPendingLink = urlencode($LatestPendingLink);
		$LatestPendingLink = strtolower($LatestPendingLink);
			
	?>
		<tr>
    <td><a href="../fact-<?php echo  $PendingFactsRow['id'];?>-<?php echo $LatestPendingLink;?>.html" target="_blank"><?php echo stripslashes( $PendingFactsRow['headline']);?></a></td>
    
    <td><abbr class="timeago" title="<?php echo $PendingFactsRow['date'];?>"></abbr></td>
</tr>
<?php
		}

    $LatestPendingFacts->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

?> 
 </tbody>
</table>

<?php if($LatestPen<1){?> 
<div class="msg">There are no pending posts at the moment.</div>
<?php }?>
</div>
</div><!--box-->
<?php include('footer.php');?>

 