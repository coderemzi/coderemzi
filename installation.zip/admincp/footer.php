</div>
<footer>
<div class="footercontaint"><div class="footerc"><span class="ftxt">Powered by</span> <a href="http://www.flippyscripts.com/">Flippy DamnFacts</a><span class="ftxt">&#8482;</span> - <a href="http://www.flippyscripts.com/">FlippyScripts</a></div></div>
</footer>
</body>
</html>