<?php

include('../db.php');

$id = $mysqli->escape_string($_GET['id']);

if($GetPost = $mysqli->query("SELECT * FROM facts WHERE id='$id'")){

    $GetRow = mysqli_fetch_array($GetPost);

	$GetPost->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

if($_POST)
{	

	if(!isset($_POST['catagory-select']) || strlen($_POST['catagory-select'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please select a category'.$Uid.'</div>');
	}
	
	if(!isset($_POST['Headline']) || strlen($_POST['Headline'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please add a headline</div>');
	}
	
	if(!isset($_POST['fact']) || strlen($_POST['fact'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please add a fact</div>');
	}

	$Headline			= $mysqli->escape_string($_POST['Headline']); // file title
	$Catagory           = $mysqli->escape_string($_POST['catagory-select']);
	$YouTube            = $mysqli->escape_string($_POST['yTube']);
	$Fact		        = $mysqli->escape_string($_POST['fact']);
	$Source		        = $mysqli->escape_string($_POST['source']);
	   
if(!isset($_POST['yTube']) || strlen($_POST['yTube'])>1)
	{
	$VideoUrl = stristr($YouTube, 'watch?v=');
	$VideoUrl = explode('=', $VideoUrl);
	$VideoUrl = explode('&', $VideoUrl[1]);
	$VideoUrl = $VideoUrl[0];
	
		
	    $videoEmbed = "<iframe width=\"630\" height=\"473\" src=\"http://www.youtube.com/embed/".$VideoUrl."\" frameborder=\"0\" allowfullscreen></iframe>\n";
	

		$mysqli->query("UPDATE facts SET headline='$Headline',catagory_id='$Catagory',video='$videoEmbed',fact='$Fact',source='$Source' WHERE id='$id'") or die (mysqli_error());
		
	}else{	   
		
		$mysqli->query("UPDATE facts SET headline='$Headline',catagory_id='$Catagory',fact='$Fact',source='$Source' WHERE id='$id'") or die (mysqli_error());
}


		die('<div class="msg-ok">Post updated successfully.</div>');

		
   }else{
   		die('<div class="msg-error">There seems to be a problem. please try again.</div>');
} 
?>